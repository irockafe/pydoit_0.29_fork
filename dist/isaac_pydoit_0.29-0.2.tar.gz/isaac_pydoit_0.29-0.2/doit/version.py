"""doit version, defined out of __init__.py to avoid circular reference"""
VERSION = (0, 29, 0)
